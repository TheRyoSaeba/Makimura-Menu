// Inject toastr CSS
const toastrCSS = document.createElement("link");
toastrCSS.setAttribute("rel", "stylesheet");
toastrCSS.setAttribute(
  "href",
  "https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css"
);
document.head.appendChild(toastrCSS);

// Inject toastr JS (standalone version)
const toastrScript = document.createElement("script");
toastrScript.setAttribute(
  "src",
  "https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"
);
document.head.appendChild(toastrScript);

// Inject the script that listens for messages from the content script
const optionsScript = document.createElement("script");
optionsScript.textContent = `
  function setupToastr() {
    toastr.options = {
      "closeButton": true,
      "debug": false,
      "newestOnTop": true,
      "progressBar": true,
      "positionClass": "toast-top-right",
      "preventDuplicates": true,
      "onclick": null,
      "showDuration": "400",
      "hideDuration": "1000",
      "timeOut": "3000",
      "extendedTimeOut": "1000",
      "showEasing": "swing",
      "hideEasing": "linear",
      "showMethod": "fadeIn",
      "hideMethod": "fadeOut"
    };

    window.addEventListener('showToastr', (event) => {
      const { type, message, title } = event.detail;
      if (['success', 'info', 'warning', 'error'].includes(type)) {
        toastr[type](message, title);
      }
    });
  }

  window.onload = setupToastr;
`;
document.head.appendChild(optionsScript);
