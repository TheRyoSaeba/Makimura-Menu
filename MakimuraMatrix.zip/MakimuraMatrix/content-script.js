(function () {
  const recaptchaScript = document.createElement("script");
  recaptchaScript.src = chrome.runtime.getURL("recaptcha.js");
  recaptchaScript.onload = function () {
    this.remove();
  };
  (document.head || document.documentElement).appendChild(recaptchaScript);
})();

// background.js

function injectScripts(tabId, scripts, index = 0) {
  if (index < scripts.length) {
    chrome.tabs.executeScript(tabId, { file: scripts[index] }, () => {
      injectScripts(tabId, scripts, index + 1);
    });
  }
}
