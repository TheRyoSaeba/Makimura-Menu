window.postMessageToPage = function (type, message) {
  window.postMessage({ type, message }, "*");
};
