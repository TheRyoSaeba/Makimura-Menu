(function () {
  // Create a container element for the Tweakpane menu
  const container = document.createElement("div");
  container.style.position = "fixed";
  container.style.top = "5px";
  container.style.left = "5px";
  document.body.appendChild(container);
  const greeting = "";
  // Initialize Tweakpane
  const pane = new Tweakpane.Pane({
    title: "Makimura Menu - Hold F or Click Notch",
    expanded: false,
  });
  const welcome = `PPPPPPPPPPGGBBGGGBBBBBBBGP5YYJJJJJJJJJY5PGBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB#BGGGGGGGGGG
PPPPPPPPGGBGPPGBBBBBBG5Y55PP5YJJJJY5GGGGGGGBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB#BBBBGGGGGGGG
PPPPPPPPGGPPGBBBBBBBPPGBBBBG5YJJJY5GBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB#BGGGGGPPPP
PPPPPPPPPPPGBBBBBBBBBBBGP5YJJYYPGBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBGPP5555YY
55PPPPPPPPG#BBBBBBBBBGP5555PPGBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBP55555Y
PPPPPPPPPGBBBBBBBBBBGGGG5PPPGBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBGGGBBGBBBG5555
PPPPPPPGBBBBBBBBBBBBBBG55PGBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBGP5PP5P5YYYYYPPPBBBBPPP
PPPPPPGBBGBBBBBBBBBBBB55GBBBBBBBBBBBBBBBBBBBB#BBB#BBBBBBBBBB#BBBBBBBBBBBBBG5Y555YJJY5PGGBGYP5GBBBBPP
PPPPPBBBGGBBBBBBBBBBBGGBBBBBBBBBBBBBBBBBBBBBGBBBB#BBBBBBBBB##BB#BBBBBBBBBBG5GBBBB5YGBBBBBBP5GGBBBBGP
PPPPGBBPGBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB5GBBGPBB#BBBBBB#BBBB#B##BBBBBBBBBBBBBBBPPBBBBBBG5BBBBBBBG
PPPGBBPPGBBBBBBBBBBBBBBBBBBBBBBBB##BBBBBGYYGBGYYBBBBBBBBBBB5BBGB#GGBBBBBBBBBBBBBBBBBBBBBBBGGBBBBBBBP
PPPG#GPPBBBBBBBBBBBBBBBBBBBBBBBBBP555YJ??YP5J7YBBPBBBBBBBGYB#PPG5JGBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBGP
PPPBBPPPGBBBBBBBBBBBBBBBBBB#BG5J?7777777??77JPB5YGBBBBGGPYGBY5G!7!G#BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBGP
PPPBGPPPPBBBBBBBBBBBBBBBBBB5?777777777777?JY5J?YBBBBPPPYYPY?5Y~^~~J#BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBPP
Y55PPPPPBBBBBBBBBBBBBBBBBBY77?JJJJYYYJ?77777?YG#BPYYYJ???!!?!^^~~~^5#BBBBBBBBBBBBBBBBBBBBBBBBBBBBGPP
YYY55PPBBGBBBBBBBBBBBBBBPJ77J????????J?J?JYPGGPY?7!!!~~^^^~^^~~~~~^~P#BBBBBBBBBBBBBBBBBBBBBBBBBBBPPP
PPPPPPPBPPBBBBBBBBBBBB#5777777JYYJJJJ?7YJ?J??7!!~~7JJJJJ??7~~^^~~~~^~JGBBBBBBBBBBBBBBBBBBBBBBBBBGP55
PPPPPPGBPPBBBBBBBBBBBBB5777?YPP55PGPPB5?Y7~~^^^^~!?777???JJJJ7!~~^~~~^~J#BBBBBBBBBBBBBBBBBBBBBBG5555
PPPPPPBGPPGBBBBBBBBBBBB57777J!:!PB&JY75J?!^^^^^^~!77?J5YJ?77???77!~~~^~G#BBBBBBBBBBBBBBBBBBBBBB55555
PPPPPPBGPPPGBBBBBBBBBBB577777~:~5PBGJ::7?7^^^^^^^^^^7G5Y5PPP55?~~~~~~^~GBBBBBBBBBBBBBBBBBBBBBBGGGGPP
PPPPPPGGPPPPGB#BBBBBBBBY7777~!!~~77!^^~?J~^^^^^^^^^^~^~5B#JJJ?PP7~~~~~^Y#BBBBBBBBBBBBBBBBBBBBGPGPPPP
PPPPPPPGPPPPPPGBBBBBBBBJ777~^^^^^^^^~~??~^^^^^^^^^^^^.7PG&GPJ.:?Y!~~~~^!GBBBBBBBBBBBBBBBBBBBGPPPPPPP
PPPPPPPPGPPPPPPPGGBBBBBJ77!^^^^^^^^~7??~^^^^^^^^^^^^^~~7JYY7::^^^~~~~~^^!PBBBBBBBBBBBBBBBBBBPPPPPPPP
PPPPPPPPPPPPPPPPPPPPB#B?77~^^^^^^~!?J7^^^^^^^^^^^^^^^^~~~~~~~!!~~~~~~^^^^5BBBBBBBBBBBBBBBBG555555555
PPPPPPPPPPPPPPPPPPPBBBG777~^^^^^~7??!^^^^^^^^^^^^^^^^^^^^^^~~^^^~~~~~^^^^P#BBBBBBBBBBBBBBB555PPPPPPP
PPPPPPPPPPPPPPPPPPGBGBG777~^^^^^~?!^^^^^^^^^^^^^^^^^^^^^^^^^~~~~~~~~~^^^!BGPBBBBBBBBBBBBBPPPPPPPPPPP
PPPPPPPPPPPPPPPPPPBGGBB?77~^^^^^^!77!!777~^^^^^^~^^^^^^^^^^~~~~~~~~~~~~^5B7~J5BBBBBBBBBBGPPPPPPPPPPP
55555PPPPPPPPPPPPPBPGBBJ77^^^^^^^^~JP555J~^^^^^^^^^~^^^^^^~~^~~~~~~~~~^?B?~~!^7GBB#BBBBBPPPPPPP55YYY
???????JJJYYYY5555G55BBP77~^^^^^^^^^~!~~^^~^^~~^^^~~^^^^~~~~~~~~~~~^~^?G7!7!!!~!BBBBBBBP5YYYJJJJ????
YJJJJJJJJJJYY55555555PBB?7~^^^^^^^^~!~^^^^^^^~^^~~~~^^~^~~~~~~~~~~~~^?P7^~~~~~!Y#BBBBBGYJJJJJJJJJJJJ
JJYYY55555PPPPPPPPPPPPGB57~^^^^^^^^7!!~~~~~^~~~^~~~^~~~~~~~~~~~~~~~^?G!^^^~7JPB#BBBBBBPP55YYYYJJJJJJ
YYYJJJJJJJJJYYYYY555555GBJ!^^^^^^^^^~~~~~!!~^~~~~~^^~~~~~^~~~~~~~~^7BB5JYPGBBBBBBBBBB5YYYYYYYYYYYYYY
YYYYYYYYYYYJJJ????J?JJJJYP?~^^^^^^^~!~~~^^^~~~~~~~~~~~~~~~~~~~~~^~~?PBBBBBBBBBBBBBBB5JJJJJJJJJJJJJJJ
YYYYYYYYYYYYYYYYYYYYJJJJJJP7^^^^^^^!???7!~~~~~~~~~~~~~~~~~~~~^^~!7!7BBBBBBBBBBBBBBBYJJJJJJJJJJJJJJJJ
JJJJJJJJJJJJJJJJJJJJJYYYYP#G7^^^^^^^^~~~~~~~~~~~~~~~~~~~~^^^~!777!^JBBBBBBBBBBBBBPYJJJYYYYYYYYYYYYYY
JJJJJJJJJJJJJJJJJJJJJJJJ5BGBBJ^^~^^^~~^^^~~~~~~~~~~~~~^^~~7?J??7~~~PBBBBBBBBBGP5YYYJJJJYYYYYJJJJJJJJ
????????????JJJJJJJJJJJJG5G#BBJ~^~~~~~~~~~~~~~~~^^^^~~7?JYJ???!~~~~GBBBBBBBGP55PPYJJJJJJJJJJJJJJJJJJ
!77777777???????????????57G#BBYY7~^^^^^^^^^^^^^~~!7?Y5YJ????7~~~~~~GBBBBBBBGP5YYJJJJJJJJJJ?J????????
~~~~~~~~~~~~!!!!!!!!!!!!!~?PBB??YYJ7!!~~!!!7??JY555YJ??????7~~~~~~~GB##BBBBGJJJ?????777777777!!!!!!!
~~~~~~~~~^~~~~~~~~~~~~~~~~^!GBJ77?Y555555555555YJ??77?????!~~~~~~~~PB#GPGB5G?~~~~~~~~~~~~~~~~~~~~~~~
^^^^^^^^^^^^^^^^^^^^~^^75GP5P#J7?7???JJYYYJJJ???7????????!~~~~~~~~^YGP555PY?J^^^^^^^^^^^^^^^^^^^^^^^
^^^^^^^^^^^^^^^^^^^^^!5B#####PJ7????7777???????????????7~~~~~~~~~~^755555555?^^^^^^^^^^^^^^^^^^^^^^^
^^^^^^^^^^^^^^^^^^~75B#####BY?J7??????????????????????!~~~~~~~~~~~~^?55555555Y7^^^^^^^^^^^^^^^^^^^^^
^^^!JYJ?!~^^^^^^~?G######B5?7JJ7????????????????????7~~~~~~~~~~~~~~~~J5P5555555Y?~^^^^^^::::::::::::`;
  console.log(
    welcome,
    " \n   THIS WAS CREATED BY MAKIMURA, PLEASE RESPECT THIS PROGRAM AND DONT ABUSE IT, "
  );
  // Append the Tweakpane menu to the container element
  container.appendChild(pane.element);

  // Set the z-index and position of the Tweakpane menu
  pane.element.parentElement.style.zIndex = "100000";
  pane.element.parentElement.style.position = "fixed";
  pane.element.parentElement.style.left = "62%";
  pane.element.parentElement.style.top = "40%";

  // Calculate initial position in pixels
  const initialLeft = window.innerWidth * 0.62;
  const initialTop = window.innerHeight * 0.4;
  pane.element.parentElement.style.left = `${initialLeft}px`;
  pane.element.parentElement.style.top = `${initialTop}px`;

  // Set the initial scale value using anime.js
  anime.set(pane.element.parentElement, { scale: 1.7 });

  // Set the initial clip-path value using anime.js
  anime.set(pane.element.parentElement, {
    clipPath: "polygon(0 0, 100% 0, 100% 100%, 0 100%)",
  });

  // Add a keyboard shortcut to show/hide the Tweakpane menu
  // Add a keyboard shortcut to show/hide the Tweakpane menu
  document.addEventListener("keydown", function (event) {
    if (event.code === "KeyF") {
      pane.element.children[0].click();
    }
  });

  // Add an event listener to animate the Tweakpane menu when it's expanded or collapsed
  pane.on("fold", (expanded) => {
    if (expanded) {
      anime({
        targets: pane.element.parentElement,
        clipPath: [
          "polygon(0 0, 100% 0, 100% 0%, 0 0%)",
          "polygon(0 0, 100% 0, 100% 100%, 0 100%)",
        ],
        duration: 500,
        easing: "easeInOutQuad",
        direction: "normal",
      });
    } else {
      anime({
        targets: pane.element.parentElement,
        clipPath: [
          "polygon(0 0, 100% 0, 100% 100%, 0 100%)",
          "polygon(0 0, 100% 0, 100% 0%, 0 0%)",
        ],
        duration: 500,
        easing: "easeInOutQuad",
        direction: "reverse",
      });
    }
  });
  let mouseDownTime;
  interact(pane.element).draggable({
    listeners: {
      start(event) {
        offsetX =
          event.clientX - parseFloat(pane.element.parentElement.style.left);
        offsetY =
          event.clientY - parseFloat(pane.element.parentElement.style.top);
        mouseDownTime = new Date().getTime();
      },
      move(event) {
        const left = event.clientX - offsetX;
        const top = event.clientY - offsetY;
        pane.element.parentElement.style.left = `${left}px`;
        pane.element.parentElement.style.top = `${top}px`;
        //get dimensions
        const windowWidth = window.innerWidth;
        const windowHeight = window.innerHeight;
        // Get the pane dimensions
        const paneWidth = pane.element.parentElement.offsetWidth;
        const paneHeight = pane.element.parentElement.offsetHeight;
        // Check if the pane is within the screen bounds
        if (
          left >= 0 &&
          left + paneWidth <= windowWidth &&
          top >= 0 &&
          top + paneHeight <= windowHeight
        ) {
          pane.element.parentElement.style.left = `${left}px`;
          pane.element.parentElement.style.top = `${top}px`;
          // Store the position in local storage
          sessionStorage.setItem(
            "tweakpane-menu-position",
            JSON.stringify({ left, top })
          );
        }
      },
    },
  });
  pane.element.children[0].children[0].addEventListener("click", (e) => {
    const currentTime = new Date().getTime();
    if (currentTime - mouseDownTime > 5) {
      // Toggle the expanded or collapsed state of the menu
    }
  });

  // Click event listener for the title bar
  pane.element.children[0].children[0].addEventListener("click", (e) => {
    const currentTime = new Date().getTime();
    if (currentTime - mouseDownTime > 5) {
      e.stopPropagation();
    }
  });
  // Get the position from local storage
  const storedPosition = sessionStorage.getItem("tweakpane-menu-position");

  if (storedPosition) {
    const { left, top } = JSON.parse(storedPosition);
    pane.element.parentElement.style.left = `${left}px`;
    pane.element.parentElement.style.top = `${top}px`;
  }

  //style the menu
  var style = document.createElement("style");
  style.innerHTML = `
 .tweakpane {
  font-size: 1.5em;
  font-family: Helvetica, sans-serif;
  pointer-events: none;
}
 

.tweakpane-title-label {
  font-size: 15px;
  white-space: nowrap;
  font-weight: bold;
  overflow: hidden;
  text-overflow: ellipsis;
  max-width: 100%;
  color: hsla(210, 80%, 70%, 1);
  
}
.tweakpane-about-icons {
  display: flex;
  justify-content: space-around;
  margin-top: 10px;
}

.tweakpane-about-icon {
  width: 24px;
  height: 24px;
  cursor: pointer;
}

.tweakpane-title-label:hover {
  color: hsla(210, 80%, 90%, 1);
}

   :root {
--tp-base-background-color: hsla(52, 0%, 10%, 0.80);
  --tp-base-shadow-color: hsla(360, 52%, 28%, 0.20);
  --tp-button-background-color: hsla(0, 0%, 80%, 1.00);
  --tp-button-background-color-active: hsla(0, 0%, 100%, 1.00);
  --tp-button-background-color-focus: hsla(0, 0%, 95%, 1.00);
  --tp-button-background-color-hover: hsla(0, 0%, 85%, 1.00);
  --tp-button-foreground-color: hsla(0, 0%, 0%, 0.80);
  --tp-container-background-color: hsla(0, 0%, 0%, 0.30);
   --tp-container-background-color-active: hsla(315, 79%, 53%, 0.60);
  --tp-container-background-color-focus: hsla(203, 86%, 45%, 0.50);
  --tp-container-background-color-hover: hsla(206, 88%, 47%, 0.40);
  --tp-container-foreground-color: hsla(0, 0%, 100%, 0.50);
   --tp-input-foreground-color: hsla(291, 6%, 10%, 0.50);
  --tp-groove-foreground-color: hsla(0, 0%, 0%, 0.20);
    --tp-input-background-color: hsla(344, 0%, 9%, 0.30);
  --tp-input-background-color-active: hsla(98, 81%, 39%, 0.50);
  --tp-input-background-color-focus: hsla(198, 81%, 39%, 0.50);
  --tp-input-background-color-hover: hsla(198, 87%, 42%, 0.40);
  --tp-input-foreground-color: hsla(0, 0%, 100%, 0.50);
  --tp-label-foreground-color: hsla(0, 0%, 100%, 0.50);
   --tp-monitor-background-color: hsla(339, 53%, 52%, 0.30);
  --tp-monitor-foreground-color: hsla(0, 0%, 3%, 0.30);
  }


 
   
}
`;
  document.head.appendChild(style);

  //load folders
  // Create the "Main Menu" tab
  const tab = pane.addTab({
    pages: [{ title: "Main Menu" }],
  });
  // Create the folders and add them to the "Main Menu" tab
  const Earn_ = tab.pages[0].addFolder({
    title: "Earns",
    expanded: false,
  });

  const Agg_ = tab.pages[0].addFolder({
    title: "Aggravated Crime",
    expanded: false,
  });

  const CS_ = tab.pages[0].addFolder({
    title: "Community Service",
    expanded: false,
  });

  const Drug_ = tab.pages[0].addFolder({
    title: "Drug Works",
    expanded: false,
  });

  const config_ = tab.pages[0].addFolder({
    title: "Config",
    expanded: false,
  });

  const tab1 = pane.addTab({
    pages: [{ title: "Restocks" }],
    direction: "vertical",
  });
  // Add a page to the "Restocks" tab

  // Add a folder for "Dog Pound" to the "Restocks" page
  const dogFolder = tab1.pages[0].addFolder({
    title: "Dog Pound",
    expanded: false,
  });

  // Add a folder for "Vehicle Restocks" to the "Restocks" page
  const vehicleFolder = tab1.pages[0].addFolder({
    title: "Vehicle Restocks",
    expanded: false,
  });

  const weaponFolder = tab1.pages[0].addFolder({
    title: "Weapon Restocks",
    expanded: false,
  });

  const casino_ = tab1.addPage({
    title: "Casino",
  });

  //load config checkbox
  var recaptchaValue = localStorage.getItem("recaptcha") === "true";
  var recaptcha = config_.addInput(
    {
      recaptcha: recaptchaValue,
    },
    "recaptcha",
    {
      label: "Recaptcha",
    }
  );

  function loadRecaptchaScript() {
    setTimeout(() => {
      postMessageToPage("success", "Activated", "Recaptcha", false);
    }, 100);

    const script = document.createElement("script");
    script.src = chrome.runtime.getURL("recaptcha.js");
    script.id = "recaptcha-script"; // Assign an ID to easily find and remove it later
    document.head.appendChild(script);
  }

  function unloadRecaptchaScript() {
    const script = document.getElementById("recaptcha-script");
    if (script) {
      script.remove();
    }

    setTimeout(() => {
      postMessageToPage("warning", "Deactivated", "Recaptcha", false);
    }, 100);
  }

  // Trigger event listener on page load
  if (recaptchaValue) {
    loadRecaptchaScript();
  }

  recaptcha.on("change", function (value) {
    localStorage.setItem("recaptcha", value.value);
    if (value.value) {
      loadRecaptchaScript();
    } else {
      unloadRecaptchaScript();
    }
  });
  // Get Earns list
  // Global variable to hold the filtered radio button values
  let filteredRadioButtonValues = [];

  // Function to get the filtered radio button values from local storage or fetch from server if not available or different
  function getFilteredRadioButtonValues() {
    const storedValues = localStorage.getItem("filteredRadioButtonValues");
    if (storedValues) {
      const storedArray = JSON.parse(storedValues);
      fetch("https://mafiamatrix.com/income/earn.asp")
        .then((response) => response.text())
        .then((data) => {
          const parser = new DOMParser();
          const htmlDoc = parser.parseFromString(data, "text/html");
          const radioButtons = htmlDoc.querySelectorAll('input[type="radio"]');
          const newValues = [];
          radioButtons.forEach((radioButton) => {
            if (!radioButton.value.toLowerCase().includes("timeout")) {
              newValues.push(radioButton.value);
            }
          });
          if (JSON.stringify(newValues) !== JSON.stringify(storedArray)) {
            localStorage.setItem(
              "filteredRadioButtonValues",
              JSON.stringify(newValues)
            );
            filteredRadioButtonValues = newValues;
          } else {
            filteredRadioButtonValues = storedArray;
          }
          createDropdownAndCheckbox(filteredRadioButtonValues);
        })
        .catch((error) => console.log("Error:", error));
    } else {
      fetch("https://mafiamatrix.com/income/earn.asp")
        .then((response) => response.text())
        .then((data) => {
          const parser = new DOMParser();
          const htmlDoc = parser.parseFromString(data, "text/html");
          const radioButtons = htmlDoc.querySelectorAll('input[type="radio"]');
          const newValues = [];
          radioButtons.forEach((radioButton) => {
            if (!radioButton.value.toLowerCase().includes("timeout")) {
              newValues.push(radioButton.value);
            }
          });
          localStorage.setItem(
            "filteredRadioButtonValues",
            JSON.stringify(newValues)
          );
          filteredRadioButtonValues = newValues;
          createDropdownAndCheckbox(filteredRadioButtonValues);
        })
        .catch((error) => console.log("Error:", error));
    }
  }

  // Function to update the filtered radio button values every 30 minutes
  function updateFilteredRadioButtonValues() {
    fetch("https://mafiamatrix.com/income/earn.asp")
      .then((response) => response.text())
      .then((data) => {
        const parser = new DOMParser();
        const htmlDoc = parser.parseFromString(data, "text/html");
        const radioButtons = htmlDoc.querySelectorAll('input[type="radio"]');
        const newValues = [];
        radioButtons.forEach((radioButton) => {
          if (!radioButton.value.toLowerCase().includes("timeout")) {
            newValues.push(radioButton.value);
          }
        });
        // Update the local storage and the filteredRadioButtonValues variable only if the new values are different
        if (
          JSON.stringify(newValues) !==
          JSON.stringify(filteredRadioButtonValues)
        ) {
          localStorage.setItem(
            "filteredRadioButtonValues",
            JSON.stringify(newValues)
          );
          filteredRadioButtonValues = newValues;
          console.log(filteredRadioButtonValues);
        }
      })
      .catch((error) => console.log("Error:", error));
  }

  // Get the filtered radio button values when the page loads
  getFilteredRadioButtonValues();

  // Update the filtered radio button values every 30 minutes
  setInterval(updateFilteredRadioButtonValues, 30 * 1000); // 30 seconds in milliseconds

  async function performAutomaticEarn() {
    // Check if the earn timer is ready
    const isReady = await isEarnTimerReady();
    if (isReady) {
      // Get the selected earn from the dropdown (if available) or from local storage (if not)
      const chosenEarn =
        localStorage.getItem("autoEarnChosenValue") ||
        earnController.chosenEarn;
      if (filteredRadioButtonValues.includes(chosenEarn)) {
        // Create an iframe to access the earn page
        const iframe = document.createElement("iframe");
        iframe.src = "https://mafiamatrix.com/income/earn.asp";
        iframe.style.display = "none";
        document.body.appendChild(iframe);

        // Wait for the iframe to load
        iframe.onload = function () {
          // Access the iframe's document
          const iframeDoc =
            iframe.contentDocument || iframe.contentWindow.document;

          // Click on the radio button for the chosen earn value
          const earnRadio = iframeDoc.querySelector(
            `input[type=radio][value="${chosenEarn}"]`
          );
          earnRadio.checked = true;
          postMessageToPage("info", earnRadio, "Attempting Earn : ", false);

          // Submit the form
          const workSubmit = iframeDoc.querySelector('[name="B1"]');
          workSubmit.click();

          // Send a message to the main page that the form has been submitted
          window.top.postMessage("earnFormSubmitted", "*");
        };
      } else {
        postMessageToPage("error", chosenEarn, "Invalid Earn : ", false);
      }
    } else {
      console.log("The Earn timer is not ready yet, waiting...");
    }
  }

  window.addEventListener("message", async (event) => {
    if (event.data === "earnFormSubmitted") {
      // Load the same page in a hidden iframe to get the updated timer value
      const hiddenIframe = document.createElement("iframe");
      hiddenIframe.src = window.location.href;
      hiddenIframe.style.display = "none";
      document.body.appendChild(hiddenIframe);

      // Wait for the hidden iframe to load
      hiddenIframe.onload = function () {
        // Access the hidden iframe's document
        const hiddenIframeDoc =
          hiddenIframe.contentDocument || hiddenIframe.contentWindow.document;

        // Get the updated timer value from the hidden iframe
        const updatedTimerValue = hiddenIframeDoc.querySelector(
          'form[name="earn"] .donation_timer'
        ).textContent;

        // Update the timer element on the main page
        document.querySelector(
          'form[name="earn"] .donation_timer'
        ).textContent = updatedTimerValue;

        // Remove the hidden iframe
        document.body.removeChild(hiddenIframe);
        postMessageToPage(
          "success",
          earnRadio,
          "Successfully clicked Earn:  ",
          false
        );
      };
    }
  });
  function createDropdownAndCheckbox() {
    const dropdownOptions = filteredRadioButtonValues.map((value) => {
      return { text: value, value: value };
    });

    const lastChosenEarnValue = localStorage.getItem("autoEarnChosenValue");
    const earnController = {
      chosenEarn:
        lastChosenEarnValue &&
        filteredRadioButtonValues.includes(lastChosenEarnValue)
          ? lastChosenEarnValue
          : filteredRadioButtonValues.length > 0
          ? filteredRadioButtonValues[0]
          : null,
      autoEarn: localStorage.getItem("autoEarn") === "true",
    };

    const earnInput = Earn_.addInput(earnController, "chosenEarn", {
      options: dropdownOptions,
      label: "Choose Earn",
    });
    // Add an event listener to handle selection changes
    earnInput.on("change", (newValue) => {
      earnController.chosenEarn = newValue.value;
      // Update the saved value in local storage if the "Auto Earn" checkbox is checked
      if (earnController.autoEarn) {
        localStorage.setItem("autoEarnChosenValue", newValue.value);
        postMessageToPage(
          "success",
          earnController.chosenEarn + "\n  has been selected. ",
          "Default Auto-Earn",
          false
        );
      }
    });

    // Get the value of the "Auto Earn" checkbox from local storage
    const autoEarnChecked = localStorage.getItem("autoEarn") === "true";

    // Add the "Auto Earn" checkbox to the Earn folder
    const autoEarnCheckbox = Earn_.addInput(earnController, "autoEarn", {
      label: "Auto Earn",
    });

    const slider = weaponFolder.addBlade({
      view: "slider",
      label: "Restock time (minutes)",
      min: 5,
      max: 30,
      value: 5,
      step: 1,
      ondragstart: (event) => {
        // Prevent dragging the whole form
        event.stopPropagation();
        event.preventDefault(); // Add this line
      },
      formatValue: (value) => {
        // Round the value to an integer
        return Math.round(value);
      },
    });

    /// Create a variable to store the slider value
    let sliderValue = 5;

    // Get the slider element
    const sliderElem = slider.controller_.viewElem_;

    // Listen for changes to the slider value
    slider.on("change", (value) => {
      console.log(`Restock time set to ${value.rawValue} minutes`);
      // Update the slider value variable
      sliderValue = value;
    });

    // Add a button to store the slider value
    const button = weaponFolder.addButton({
      title: "Save Restock Time",
      onClick: () => {
        // Disable the slider
        slider.disabled = true;
        console.log(`Slider value saved: ${sliderValue}`);
        // Do something with the slider value, like send it to the server
      },
    });

    // Handle button click event using on()
    button.on("click", () => {
      // Disable the slider
      slider.disabled = true;
      console.log(`Slider value saved: ${sliderValue}`);
      // Do something with the slider value, like send it to the server
    });

    // Add an event listener to update the value of autoEarnChosenValue in localStorage when autoEarnCheckbox is checked
    let intervalId;
    intervalId = setInterval(function () {
      if (localStorage.getItem("autoEarn") == "true") {
        performAutomaticEarn(); // Call performAutomaticEarn every 10 seconds if autoEarn is checked
      }
    }, 10000);

    autoEarnCheckbox.on("change", (value) => {
      if (!value.value) {
        postMessageToPage("warning", "Disabled!", "Auto-Earn : ", false);
      }
      localStorage.setItem("autoEarn", value.value);
      localStorage.setItem("autoEarnChosenValue", earnController.chosenEarn);
      if (value.value) {
        postMessageToPage(
          "success",
          earnController.chosenEarn + "\n  has been selected !. ",
          "Default Auto-Earn",
          false
        );
        performAutomaticEarn(); // run immediately when autoEarn is checked
      }
    });

    // Set the value of the dropdown directly using the lastChosenEarnValue
    if (lastChosenEarnValue) {
      earnController.chosenEarn = lastChosenEarnValue;
    }
  }

  function postMessageToPage(type, message, title = "", onLoad = false) {
    const postMessage = () => {
      const event = new CustomEvent("showToastr", {
        detail: { type, message, title },
      });
      window.dispatchEvent(event);
    };

    onLoad ? window.addEventListener("load", postMessage) : postMessage();
  }
  // Add the playSoundOnHover function
  function playSoundOnHover(element) {
    const sound = new Audio(chrome.runtime.getURL("select.wav"));
    sound.volume = 0.4; // Set the volume to 20%

    element.addEventListener("mouseover", () => {
      sound.currentTime = 0;
      sound.play();
    });
  }

  // Use setTimeout to wait for the folder header elements to be available
  setTimeout(() => {
    const folders = document.querySelectorAll(".tp-fldv_t");

    folders.forEach((folder) => {
      playSoundOnHover(folder);
    });
  }, 100); // Wait for 100 milliseconds
})();
