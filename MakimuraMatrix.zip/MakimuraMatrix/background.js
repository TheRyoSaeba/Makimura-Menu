chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "createNotification") {
    chrome.notifications.create("myNotification", {
      type: "basic",
      iconUrl: "icons/icon48.png",
      title: "My Notification Title",
      message: "My Notification Message",
    });
  }
});
