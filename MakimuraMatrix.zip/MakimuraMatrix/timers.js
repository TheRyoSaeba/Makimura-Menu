async function isEarnTimerReady() {
  const timer = document.querySelector('form[name="earn"] .donation_timer');
  return timer && timer.textContent.trim() === "Ready";
}

async function isActionTimerReady() {
  const timer = document.querySelector('form[name="action"] .donation_timer');
  return timer && timer.textContent.trim() === "Ready";
}

async function isAggTimerReady() {
  const script = `
    (function() {
      const bar = document.querySelector('#display_bar .display_green');
      if (bar) {
        const width = bar.style.width;
        const percent = parseInt(width.replace('%', ''));
        if (percent >= 70) {
          return true;
        }
      }
      return false;
    })();
  `;

  const tabs = await chrome.tabs.query({ url: "https://mafiamatrix.com/*" });

  for (let i = 0; i < tabs.length; i++) {
    const result = await chrome.tabs.executeScript(tabs[i].id, {
      code: script,
    });
    if (result[0] === true) {
      return true;
    }
  }

  return false;
}
// attach the functions to the global object
window.isEarnTimerReady = isEarnTimerReady;
window.isActionTimerReady = isActionTimerReady;
window.isAggTimerReady = isAggTimerReady;
